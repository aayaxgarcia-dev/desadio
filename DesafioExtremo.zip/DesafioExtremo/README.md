# DesafioExtremo

Plugin propio para Paper 1.21.11 (Java 21) que junta, hecho desde cero:

- **Animaciones** con frames Unicode del resource pack (`/de animation play|stop|list`).
- **Ruletas** (`/de roulette`) con orden repartido: la ruleta roja y "momento Reviil" (y la rosada y "momento nutria") nunca quedan seguidas.
- **Extremo**: vidas, vida maxima, hazard, PvP global y anuncios.

## Compilar (GitHub Actions)

1. Sube esta carpeta a un repo de GitHub.
2. Ve a la pestana **Actions** → workflow **Build** → cuando termine, descarga el artefacto `DesafioExtremo` (el `.jar`).
3. Ponlo en `plugins/` y reinicia el servidor.

Tambien se puede compilar a mano con `gradle build` (Java 21); el jar queda en `build/libs/`.

## Comandos (permiso `desafioextremo.admin`, por defecto OP)

| Comando | Que hace |
|---|---|
| `/de help`, `/de reload`, `/de info [jugador]` | Ayuda, recarga y estado de un jugador |
| `/de animation play <animacion> <jugador\|selector\|*> [broadcast]` | Reproduce una animacion (con `broadcast` el resto ve la variante broadcast) |
| `/de animation stop [jugador\|*]`, `/de animation list` | Detiene / lista |
| `/de roulette <color\|animacion> <jugador\|*> ["titulo"] ["mensaje"]` | Lanza una ruleta concreta |
| `/de roulette random <jugador\|*> ["titulo"] ["mensaje"]` | Elige la siguiente del pool sin juntar las parejas prohibidas |
| `/de roulette history` | Ultimas ruletas |
| `/de modify lifes current\|broken <jugador\|*> add\|set\|remove\|reset [n]` | Vidas actuales / slots rotos |
| `/de modify health <jugador\|*> add\|set\|remove\|reset [puntos]` | Vida maxima (2 puntos = 1 corazon) |
| `/de modify hazard level\|time <jugador\|*> add\|set\|remove\|reset [valor]` | Nivel o tiempo de hazard (`30s`, `5m`, `12h`, `2d`, `-1`) |
| `/de pvp on\|off\|status` | PvP global |
| `/de announce difficulty_change\|announcement <jugador\|*> "titulo" "mensaje"` | Anuncios |

Permiso extra: `desafioextremo.bypass.lose_life` (no pierde vidas).

## Orden de las ruletas

En `config.yml`:

```yaml
roulette:
  pool: [aqua_roulette, ..., otter_moment, reviil_moment]
  forbidden_pairs:
    - [red_roulette, reviil_moment]
    - [pink_roulette, otter_moment]
  pair_gap: 2
```

Salen todas una vez antes de repetir; una no vuelve a salir dentro de las ultimas `pair_gap` jugadas y
los pares prohibidos quedan separados por al menos `pair_gap` jugadas. El historial se guarda en `data.yml`.
Ninguna animacion lanza otra al terminar (no existe `after`).

## Animaciones

`animations.yml` trae las ruletas, `otter_moment`, `reviil_moment` y `death` con los rangos Unicode y sonidos
`zypherd4v:*`. Las animaciones de Extremo (`lost_life`, `lost_slot`, `eliminated`, `pvp_on`, `pvp_off`,
`difficulty_change`, `announcement`) vienen con sus sonidos `zyphere3v:*` pero **sin glifos**: pon `start` y `end`
(los caracteres de tu font `zyphere3v:default`) para que se vean; mientras tanto solo suenan.

## Notas

- Los datos de jugadores (vidas, vida maxima, hazard) y el estado del PvP estan en `plugins/DesafioExtremo/data.yml`.
- Es independiente de WonderEvents: si dejas instaladas las expansiones Extremo/Dedsafio a la vez, se duplicaran mensajes y animaciones. Quitalas al usar este plugin.
