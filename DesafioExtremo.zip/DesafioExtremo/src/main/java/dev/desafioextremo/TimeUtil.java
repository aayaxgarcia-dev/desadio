package dev.desafioextremo;

/** Duraciones con formato 30s, 5m, 12h, 2d, 100t o -1 (infinito). Se manejan en milisegundos. */
public final class TimeUtil {

    public static final long INFINITE = -1L;

    private TimeUtil() {
    }

    public static long parse(String raw) {
        if (raw == null) throw new IllegalArgumentException("vacio");
        String s = raw.trim().toLowerCase();
        if (s.equals("-1")) return INFINITE;
        if (s.length() < 2) throw new IllegalArgumentException(raw);
        char unit = s.charAt(s.length() - 1);
        long amount;
        try {
            amount = Long.parseLong(s.substring(0, s.length() - 1));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(raw);
        }
        if (amount < 0) throw new IllegalArgumentException(raw);
        return switch (unit) {
            case 't' -> amount * 50L;
            case 's' -> amount * 1000L;
            case 'm' -> amount * 60_000L;
            case 'h' -> amount * 3_600_000L;
            case 'd' -> amount * 86_400_000L;
            default -> throw new IllegalArgumentException(raw);
        };
    }

    public static String format(long millis) {
        if (millis < 0) return "infinito";
        long totalSeconds = millis / 1000L;
        long d = totalSeconds / 86_400L;
        long h = (totalSeconds % 86_400L) / 3_600L;
        long m = (totalSeconds % 3_600L) / 60L;
        long s = totalSeconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 || sb.length() == 0) sb.append(s).append("s");
        return sb.toString().trim();
    }
}
