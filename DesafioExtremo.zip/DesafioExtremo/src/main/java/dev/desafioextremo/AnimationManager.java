package dev.desafioextremo;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Reproduce animaciones hechas con caracteres Unicode de un font del resource pack.
 * Cada frame es un caracter entre "start" y "end"; se muestra como TITLE, SUBTITLE o ACTIONBAR.
 */
public final class AnimationManager {

    public enum Display { TITLE, SUBTITLE, ACTIONBAR, NULL }

    private record SoundDef(Key id, Sound.Source source, float volume, float pitch) {
        Sound toSound() {
            return Sound.sound(id, source, volume, pitch);
        }
    }

    private record Anim(String key, Key font, int start, int end, int tick,
                        Display displayPlayer, Display displayBroadcast,
                        SoundDef soundPlayer, SoundDef soundBroadcast,
                        SoundDef chatPlayer, SoundDef chatBroadcast) {
        int frames() {
            return end - start + 1;
        }
    }

    private final class Run extends BukkitRunnable {
        private final Anim anim;
        private final Set<UUID> viewers = new HashSet<>();
        private final Set<UUID> affected = new HashSet<>();
        private int index = 0;

        Run(Anim anim, Collection<UUID> affected, Collection<UUID> others) {
            this.anim = anim;
            this.affected.addAll(affected);
            this.viewers.addAll(affected);
            this.viewers.addAll(others);
        }

        @Override
        public void run() {
            int cp = anim.start() + index;
            if (cp > anim.end() || viewers.isEmpty()) {
                finish();
                return;
            }
            Component frame = Component.text(new String(Character.toChars(cp))).font(anim.font());
            long stayMs = Math.max(anim.tick(), 1) * 50L * 3L;
            for (UUID id : new ArrayList<>(viewers)) {
                Player p = Bukkit.getPlayer(id);
                if (p == null) {
                    viewers.remove(id);
                    continue;
                }
                Display d = affected.contains(id) ? anim.displayPlayer() : anim.displayBroadcast();
                show(p, d, frame, stayMs);
            }
            index++;
        }

        void drop(UUID id) {
            viewers.remove(id);
        }

        private void finish() {
            cancel();
            for (UUID id : viewers) {
                Set<Run> set = running.get(id);
                if (set != null) {
                    set.remove(this);
                    if (set.isEmpty()) running.remove(id);
                }
            }
            viewers.clear();
        }
    }

    private final JavaPlugin plugin;
    private final Map<String, Anim> anims = new LinkedHashMap<>();
    private final Map<UUID, Set<Run>> running = new HashMap<>();

    public AnimationManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ carga

    public void load(FileConfiguration cfg) {
        stopAll();
        anims.clear();
        ConfigurationSection root = cfg.getConfigurationSection("animations");
        if (root == null) {
            plugin.getLogger().warning("animations.yml no tiene la seccion 'animations'.");
            return;
        }
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            try {
                anims.put(key, parse(key, s));
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Animacion '" + key + "' ignorada: " + ex.getMessage());
            }
        }
        plugin.getLogger().info("Animaciones cargadas: " + anims.size());
    }

    private Anim parse(String key, ConfigurationSection s) {
        String fontRaw = s.getString("font", "minecraft:default");
        Key font = Key.key(fontRaw);
        String startRaw = s.getString("start", "");
        String endRaw = s.getString("end", startRaw);
        int start;
        int end;
        if (startRaw.isEmpty()) {
            // Sin frames: la animacion solo reproduce sonido (util mientras no hay glifos definidos).
            start = 1;
            end = 0;
        } else {
            start = startRaw.codePointAt(0);
            end = endRaw.isEmpty() ? start : endRaw.codePointAt(0);
            if (end < start) throw new IllegalArgumentException("'end' es menor que 'start'");
        }
        int tick = Math.max(1, s.getInt("tick", 1));
        Display dp = display(s.getString("display.player", "TITLE"));
        Display db = display(s.getString("display.broadcast", "NULL"));
        return new Anim(key, font, start, end, tick, dp, db,
                sound(s.getConfigurationSection("sounds.player")),
                sound(s.getConfigurationSection("sounds.broadcast")),
                sound(s.getConfigurationSection("chat_sounds.player")),
                sound(s.getConfigurationSection("chat_sounds.broadcast")));
    }

    private static Display display(String raw) {
        try {
            return Display.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return Display.NULL;
        }
    }

    private static SoundDef sound(ConfigurationSection s) {
        if (s == null) return null;
        String id = s.getString("sound", "");
        if (id.isBlank()) return null;
        Sound.Source source;
        try {
            source = Sound.Source.valueOf(s.getString("channel", "master").trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            source = Sound.Source.MASTER;
        }
        return new SoundDef(Key.key(id), source, (float) s.getDouble("volume", 1.0), (float) s.getDouble("pitch", 1.0));
    }

    // ----------------------------------------------------------------- consulta

    public boolean has(String key) {
        return anims.containsKey(key);
    }

    public Set<String> keys() {
        return anims.keySet();
    }

    /** Duracion total en ticks (para encadenar mensajes de chat al terminar). */
    public int durationTicks(String key) {
        Anim a = anims.get(key);
        return a == null ? 0 : a.frames() * a.tick();
    }

    // ----------------------------------------------------------------- reproducir

    /**
     * @param affected        jugadores "afectados" (variante player)
     * @param includeOthers   si es true, el resto de jugadores online ve la variante broadcast
     */
    public boolean play(String key, Collection<? extends Player> affected, boolean includeOthers) {
        Anim a = anims.get(key);
        if (a == null) return false;
        Set<UUID> affectedIds = new HashSet<>();
        for (Player p : affected) affectedIds.add(p.getUniqueId());
        Set<UUID> others = new HashSet<>();
        if (includeOthers) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!affectedIds.contains(p.getUniqueId())) others.add(p.getUniqueId());
            }
        }

        // Una animacion nueva reemplaza la que el jugador estuviera viendo.
        Set<UUID> all = new HashSet<>(affectedIds);
        all.addAll(others);
        for (UUID id : all) stopFor(id, false);

        for (UUID id : affectedIds) playSound(id, a.soundPlayer());
        for (UUID id : others) playSound(id, a.soundBroadcast());

        Run run = new Run(a, affectedIds, others);
        for (UUID id : all) running.computeIfAbsent(id, k -> new HashSet<>()).add(run);
        run.runTaskTimer(plugin, 0L, a.tick());
        return true;
    }

    /** Reproduce la variante "broadcast" solo para los jugadores indicados (anuncios, PvP, etc.). */
    public boolean playTo(String key, Collection<? extends Player> targets) {
        Anim a = anims.get(key);
        if (a == null) return false;
        Set<UUID> others = new HashSet<>();
        for (Player p : targets) others.add(p.getUniqueId());
        for (UUID id : others) stopFor(id, false);
        for (UUID id : others) playSound(id, a.soundBroadcast());
        Run run = new Run(a, Set.of(), others);
        for (UUID id : others) running.computeIfAbsent(id, k -> new HashSet<>()).add(run);
        run.runTaskTimer(plugin, 0L, a.tick());
        return true;
    }

    /** Sonido de chat de la variante "broadcast" para los jugadores indicados. */
    public void playChatSoundTo(String key, Collection<? extends Player> targets) {
        Anim a = anims.get(key);
        if (a == null) return;
        for (Player p : targets) playSound(p.getUniqueId(), a.chatBroadcast());
    }

    /** Sonido que acompana al mensaje de chat de la animacion. */
    public void playChatSound(String key, Collection<? extends Player> affected, boolean includeOthers) {
        Anim a = anims.get(key);
        if (a == null) return;
        Set<UUID> affectedIds = new HashSet<>();
        for (Player p : affected) {
            affectedIds.add(p.getUniqueId());
            playSound(p.getUniqueId(), a.chatPlayer());
        }
        if (includeOthers) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!affectedIds.contains(p.getUniqueId())) playSound(p.getUniqueId(), a.chatBroadcast());
            }
        }
    }

    private void playSound(UUID id, SoundDef def) {
        if (def == null) return;
        Player p = Bukkit.getPlayer(id);
        if (p != null) p.playSound(def.toSound());
    }

    private static void show(Player p, Display d, Component frame, long stayMs) {
        switch (d) {
            case TITLE -> p.showTitle(Title.title(frame, Component.empty(),
                    Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMs), Duration.ZERO)));
            case SUBTITLE -> p.showTitle(Title.title(Component.text(" "), frame,
                    Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMs), Duration.ZERO)));
            case ACTIONBAR -> p.sendActionBar(frame);
            case NULL -> { }
        }
    }

    // ----------------------------------------------------------------- detener

    public void stopFor(Player p) {
        stopFor(p.getUniqueId(), true);
    }

    private void stopFor(UUID id, boolean clearScreen) {
        Set<Run> set = running.remove(id);
        if (set != null) {
            for (Run r : new ArrayList<>(set)) {
                r.drop(id);
                if (r.viewers.isEmpty()) r.cancel();
            }
        }
        if (clearScreen) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.clearTitle();
                p.sendActionBar(Component.empty());
            }
        }
    }

    public void stopAll() {
        for (UUID id : new ArrayList<>(running.keySet())) stopFor(id, true);
        running.clear();
    }

    public List<String> keyList() {
        return new ArrayList<>(anims.keySet());
    }
}
