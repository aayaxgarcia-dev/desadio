package dev.desafioextremo;

import dev.desafioextremo.DataStore.PlayerData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Hazard (peligrosidad): se sube de nivel matando jugadores, el nivel expira con el tiempo
 * y al morir en ciertos niveles se aplican penalizaciones.
 */
public final class HazardService {

    private static final String TEAM_PREFIX = "dehz_";

    private final DesafioExtremo plugin;
    private final GameService game;

    public HazardService(DesafioExtremo plugin, GameService game) {
        this.plugin = plugin;
        this.game = game;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("gameplay.hazard.enable", false);
    }

    private ConfigurationSection level(int n) {
        return plugin.getConfig().getConfigurationSection("gameplay.hazard.levels." + n);
    }

    private boolean levelEnabled(int n) {
        if (n == 1) return level(1) != null;
        ConfigurationSection s = level(n);
        return s != null && s.getBoolean("enabled", true);
    }

    /** Siguiente nivel habilitado por encima de 'from', o 0 si no hay. */
    private int nextLevel(int from) {
        for (int n = from + 1; level(n) != null; n++) {
            if (levelEnabled(n)) return n;
        }
        return 0;
    }

    /** Nivel habilitado inmediatamente por debajo de 'from' (minimo 1). */
    private int previousLevel(int from) {
        for (int n = from - 1; n >= 1; n--) {
            if (levelEnabled(n)) return n;
        }
        return 1;
    }

    public int maxLevel() {
        int max = 1;
        for (int n = 2; level(n) != null; n++) {
            if (levelEnabled(n)) max = n;
        }
        return max;
    }

    private long durationOf(int n) {
        ConfigurationSection s = level(n);
        if (s == null) return TimeUtil.INFINITE;
        try {
            return TimeUtil.parse(s.getString("expiration.duration", "-1"));
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Duracion invalida en hazard nivel " + n);
            return TimeUtil.INFINITE;
        }
    }

    private long maxDurationOf(int n) {
        ConfigurationSection s = level(n);
        if (s == null) return TimeUtil.INFINITE;
        try {
            return TimeUtil.parse(s.getString("expiration.max_duration", "-1"));
        } catch (IllegalArgumentException ex) {
            return TimeUtil.INFINITE;
        }
    }

    private void restartTimer(PlayerData d) {
        long dur = durationOf(d.hazardLevel);
        d.hazardExpires = dur < 0 ? TimeUtil.INFINITE : System.currentTimeMillis() + dur;
        capTimer(d);
    }

    private void capTimer(PlayerData d) {
        long max = maxDurationOf(d.hazardLevel);
        if (max > 0 && d.hazardExpires > 0) {
            d.hazardExpires = Math.min(d.hazardExpires, System.currentTimeMillis() + max);
        }
    }

    // ------------------------------------------------------------------ eventos

    public void onKill(Player killer) {
        PlayerData d = game.data(killer);
        int next = nextLevel(d.hazardLevel);
        if (next == 0) {
            // Ya esta en el nivel mas alto: cada kill suma tiempo si el nivel acumula.
            ConfigurationSection cur = level(d.hazardLevel);
            if (cur != null && cur.getBoolean("expiration.stack_duration", false)) {
                long dur = durationOf(d.hazardLevel);
                if (dur > 0 && d.hazardExpires > 0) {
                    d.hazardExpires += dur;
                    capTimer(d);
                }
            }
            plugin.data().saveAsync();
            return;
        }
        d.hazardKills++;
        int required = Math.max(1, level(next).getInt("required_kills", 1));
        if (d.hazardKills >= required) {
            d.hazardLevel = next;
            d.hazardKills = 0;
            restartTimer(d);
            killer.sendMessage(plugin.msg().get("hazard.level_up", game.placeholders(killer, d)));
            applyTag(killer);
        }
        plugin.data().saveAsync();
    }

    public void onDeath(Player victim) {
        PlayerData d = game.data(victim);
        ConfigurationSection s = level(d.hazardLevel);
        if (s == null) return;
        // Las penalizaciones usan el nivel que tenia al morir.
        java.util.List<String> actions = s.getStringList("penalties_actions");
        boolean downgrade = s.getBoolean("death.downgrade", false);
        boolean resetTimer = s.getBoolean("death.reset_expiration", false);

        if (downgrade && d.hazardLevel > 1) {
            d.hazardLevel = previousLevel(d.hazardLevel);
            d.hazardKills = 0;
            restartTimer(d);
        } else if (resetTimer) {
            restartTimer(d);
        }
        if (!actions.isEmpty()) game.runActions(victim, actions);
        applyTag(victim);
        plugin.data().saveAsync();
    }

    /** Se llama cada pocos segundos: baja el nivel de quien ya expiro. */
    public void tick() {
        if (!enabled()) return;
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = game.data(p);
            if (d.hazardLevel <= 1 || d.hazardExpires < 0 || now < d.hazardExpires) continue;
            d.hazardLevel = previousLevel(d.hazardLevel);
            d.hazardKills = 0;
            restartTimer(d);
            p.sendMessage(plugin.msg().get("hazard.level_down", game.placeholders(p, d)));
            applyTag(p);
            changed = true;
        }
        if (changed) plugin.data().saveAsync();
    }

    // ------------------------------------------------------------------ comandos

    public void setLevel(PlayerData d, GameService.Action action, int value) {
        int target = GameService.apply(d.hazardLevel, action, value, 1);
        target = Math.max(1, Math.min(target, maxLevel()));
        if (!levelEnabled(target)) target = previousLevel(target);
        d.hazardLevel = target;
        d.hazardKills = 0;
        restartTimer(d);
        Player online = Bukkit.getPlayer(d.id);
        if (online != null) applyTag(online);
    }

    /** value en milisegundos; -1 = infinito. */
    public void setTime(PlayerData d, GameService.Action action, long value) {
        long now = System.currentTimeMillis();
        switch (action) {
            case RESET -> restartTimer(d);
            case SET -> d.hazardExpires = value < 0 ? TimeUtil.INFINITE : now + value;
            case ADD -> {
                long base = d.hazardExpires < 0 ? now : d.hazardExpires;
                d.hazardExpires = base + value;
            }
            case REMOVE -> {
                long base = d.hazardExpires < 0 ? now : d.hazardExpires;
                d.hazardExpires = Math.max(now, base - value);
            }
        }
    }

    public long remainingMillis(PlayerData d) {
        if (d.hazardExpires < 0) return TimeUtil.INFINITE;
        return Math.max(0, d.hazardExpires - System.currentTimeMillis());
    }

    // ------------------------------------------------------------------ tags (equipos)

    public void applyTag(Player p) {
        if (Bukkit.getScoreboardManager() == null) return;
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        PlayerData d = game.data(p);
        Team existing = sb.getEntryTeam(p.getName());
        boolean ours = existing != null && existing.getName().startsWith(TEAM_PREFIX);

        ConfigurationSection tag = enabled() && level(d.hazardLevel) != null
                ? level(d.hazardLevel).getConfigurationSection("tag") : null;
        boolean wants = tag != null && tag.getBoolean("enabled", false);

        if (existing != null && !ours && !(wants && tag.getBoolean("bypass", false))) return;
        if (ours) existing.removeEntry(p.getName());
        if (!wants) return;

        String teamName = TEAM_PREFIX + d.hazardLevel;
        Team team = sb.getTeam(teamName);
        if (team == null) team = sb.registerNewTeam(teamName);
        NamedTextColor color = NamedTextColor.NAMES.value(tag.getString("color", "white").toLowerCase());
        if (color == null) color = NamedTextColor.WHITE;
        team.color(color);
        team.prefix(Component.text(tag.getString("prefix", "") + " ", color));
        team.addEntry(p.getName());
    }

    public void clearTags() {
        if (Bukkit.getScoreboardManager() == null) return;
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team t : new java.util.ArrayList<>(sb.getTeams())) {
            if (t.getName().startsWith(TEAM_PREFIX)) t.unregister();
        }
    }
}
