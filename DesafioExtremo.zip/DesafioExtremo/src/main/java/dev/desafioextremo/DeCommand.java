package dev.desafioextremo;

import dev.desafioextremo.DataStore.PlayerData;
import dev.desafioextremo.GameService.Action;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public final class DeCommand implements TabExecutor {

    private static final String PERMISSION = "desafioextremo.admin";

    private final DesafioExtremo plugin;

    public DeCommand(DesafioExtremo plugin) {
        this.plugin = plugin;
    }

    private Msg msg() {
        return plugin.msg();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            msg().send(sender, "no_permission");
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help" -> help(sender);
            case "reload" -> reload(sender);
            case "info" -> info(sender, args);
            case "animation", "animacion" -> animation(sender, args);
            case "roulette", "ruleta" -> roulette(sender, args);
            case "modify" -> modify(sender, args);
            case "pvp" -> pvp(sender, args);
            case "announce" -> announce(sender, args);
            default -> help(sender);
        }
        return true;
    }

    // ------------------------------------------------------------------ utilidades

    private void usage(CommandSender sender, String text) {
        msg().send(sender, "invalid_usage", Msg.ph("usage", text));
    }

    /** Resuelve "*", selectores (@a, @p...) o un jugador conectado. Devuelve null si no hay nada valido. */
    private List<Player> players(CommandSender sender, String token) {
        List<Player> out = new ArrayList<>();
        if (token.equals("*")) {
            out.addAll(Bukkit.getOnlinePlayers());
            return out;
        }
        if (token.startsWith("@")) {
            try {
                for (Entity e : Bukkit.selectEntities(sender, token)) {
                    if (e instanceof Player p) out.add(p);
                }
            } catch (IllegalArgumentException ex) {
                return null;
            }
            return out.isEmpty() ? null : out;
        }
        Player p = Bukkit.getPlayerExact(token);
        if (p == null) return null;
        out.add(p);
        return out;
    }

    /** Igual que players(), pero tambien acepta jugadores que no estan conectados pero ya tienen datos. */
    private List<PlayerData> dataTargets(CommandSender sender, String token) {
        List<PlayerData> out = new ArrayList<>();
        if (token.equals("*")) {
            for (Player p : Bukkit.getOnlinePlayers()) plugin.game().data(p);
            out.addAll(plugin.data().all());
            return out;
        }
        List<Player> online = token.startsWith("@") ? players(sender, token) : null;
        if (online != null) {
            for (Player p : online) out.add(plugin.game().data(p));
            return out;
        }
        Player exact = Bukkit.getPlayerExact(token);
        if (exact != null) {
            out.add(plugin.game().data(exact));
            return out;
        }
        PlayerData stored = plugin.data().findByName(token);
        if (stored == null) return null;
        out.add(stored);
        return out;
    }

    /** Separa "texto entre comillas" y palabras sueltas a partir de 'from'. */
    private static List<String> tokens(String[] args, int from) {
        String joined = String.join(" ", Arrays.copyOfRange(args, from, args.length));
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        boolean any = false;
        for (int i = 0; i < joined.length(); i++) {
            char c = joined.charAt(i);
            if (c == '"') {
                quoted = !quoted;
                any = true;
            } else if (c == ' ' && !quoted) {
                if (any || cur.length() > 0) out.add(cur.toString());
                cur.setLength(0);
                any = false;
            } else {
                cur.append(c);
            }
        }
        if (any || cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private static Integer parseInt(String raw) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    // ------------------------------------------------------------------ help / reload / info

    private void help(CommandSender sender) {
        for (Component line : msg().list("messages.help")) sender.sendMessage(line);
    }

    private void reload(CommandSender sender) {
        long start = System.currentTimeMillis();
        boolean ok = plugin.reloadAll();
        if (ok) msg().send(sender, "reload.success", Msg.ph("time", System.currentTimeMillis() - start));
        else msg().send(sender, "reload.failed");
    }

    private void info(CommandSender sender, String[] args) {
        PlayerData d;
        if (args.length >= 2) {
            List<PlayerData> found = dataTargets(sender, args[1]);
            if (found == null || found.isEmpty()) {
                msg().send(sender, "invalid_player", Msg.ph("player", args[1]));
                return;
            }
            d = found.get(0);
        } else if (sender instanceof Player p) {
            d = plugin.game().data(p);
        } else {
            usage(sender, "/de info <jugador>");
            return;
        }
        long left = plugin.hazard().remainingMillis(d);
        msg().send(sender, "info", plugin.game().placeholders(Bukkit.getPlayer(d.id), d)[0],
                Msg.ph("lives", d.lives), Msg.ph("max_lives", plugin.game().maxLives(d)),
                Msg.ph("broken", d.broken), Msg.ph("health", d.healthPoints),
                Msg.ph("hearts", d.healthPoints / 2.0), Msg.ph("hazard_level", d.hazardLevel),
                Msg.ph("hazard_time", TimeUtil.format(left)),
                Msg.ph("pvp", plugin.game().pvpEnabled() ? "activado" : "desactivado"));
    }

    // ------------------------------------------------------------------ animation

    private void animation(CommandSender sender, String[] args) {
        if (args.length < 2) {
            usage(sender, "/de animation <play|stop|list> ...");
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> msg().send(sender, "animation.list", Msg.ph("list", String.join(", ", plugin.animations().keyList())));
            case "play" -> {
                if (args.length < 4) {
                    usage(sender, "/de animation play <animacion> <jugador|selector|*> [broadcast]");
                    return;
                }
                String key = args[2].toLowerCase(Locale.ROOT);
                if (!plugin.animations().has(key)) {
                    msg().send(sender, "animation.unknown", Msg.ph("animation", key));
                    return;
                }
                List<Player> targets = players(sender, args[3]);
                if (targets == null) {
                    msg().send(sender, "invalid_player", Msg.ph("player", args[3]));
                    return;
                }
                boolean others = args.length >= 5 && args[4].equalsIgnoreCase("broadcast");
                plugin.animations().play(key, targets, others);
                msg().send(sender, "animation.playing", Msg.ph("animation", key), Msg.ph("target", args[3]));
            }
            case "stop" -> {
                List<Player> targets = args.length >= 3 ? players(sender, args[2]) : new ArrayList<>(Bukkit.getOnlinePlayers());
                if (targets == null) {
                    msg().send(sender, "invalid_player", Msg.ph("player", args[2]));
                    return;
                }
                for (Player p : targets) plugin.animations().stopFor(p);
                msg().send(sender, "animation.stopped");
            }
            default -> usage(sender, "/de animation <play|stop|list> ...");
        }
    }

    // ------------------------------------------------------------------ roulette

    private void roulette(CommandSender sender, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("history")) {
            msg().send(sender, "roulette.history", Msg.ph("list", String.join(" > ", plugin.roulette().history())));
            return;
        }
        if (args.length < 3) {
            usage(sender, "/de roulette <color|random|animacion> <jugador|selector|*> [\"titulo\"] [\"mensaje\"]");
            return;
        }
        List<Player> targets = players(sender, args[2]);
        if (targets == null) {
            msg().send(sender, "invalid_player", Msg.ph("player", args[2]));
            return;
        }
        String key;
        if (args[1].equalsIgnoreCase("random")) {
            if (!plugin.roulette().hasPool()) {
                msg().send(sender, "roulette.no_pool");
                return;
            }
            key = plugin.roulette().nextRandom();
        } else {
            key = plugin.roulette().resolveKey(args[1]);
            if (key == null) {
                msg().send(sender, "animation.unknown", Msg.ph("animation", args[1]));
                return;
            }
        }
        List<String> text = tokens(args, 3);
        String title = text.size() >= 1 ? text.get(0) : plugin.getConfig().getString("roulette.default_title", "Ruleta");
        String message = text.size() >= 2 ? text.get(1) : plugin.getConfig().getString("roulette.default_message", "");
        plugin.roulette().play(key, targets, title, message);
        msg().send(sender, "roulette.success", Msg.ph("animation", key), Msg.ph("target", args[2]));
    }

    // ------------------------------------------------------------------ modify

    private void modify(CommandSender sender, String[] args) {
        String usage = "/de modify <lifes|health|hazard> <(lifes: current|broken)|(hazard: level|time)> <jugador|*> <add|set|remove|reset> <valor>";
        if (args.length < 2) {
            usage(sender, usage);
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "lifes", "lives" -> modifyLifes(sender, args, usage);
            case "health" -> modifyHealth(sender, args, usage);
            case "hazard" -> modifyHazard(sender, args, usage);
            default -> msg().send(sender, "modify.invalid_category");
        }
    }

    private void modifyLifes(CommandSender sender, String[] args, String usage) {
        if (args.length < 5) {
            usage(sender, usage);
            return;
        }
        boolean broken;
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "current" -> broken = false;
            case "broken" -> broken = true;
            default -> {
                msg().send(sender, "modify.invalid_subtype");
                return;
            }
        }
        List<PlayerData> targets = dataTargets(sender, args[3]);
        if (targets == null) {
            msg().send(sender, "invalid_player", Msg.ph("player", args[3]));
            return;
        }
        Action action = Action.parse(args[4]);
        if (action == null) {
            msg().send(sender, "modify.invalid_action");
            return;
        }
        int value = 0;
        if (action != Action.RESET) {
            Integer v = args.length >= 6 ? parseInt(args[5]) : null;
            if (v == null) {
                msg().send(sender, "modify.invalid_number");
                return;
            }
            value = v;
        }
        for (PlayerData d : targets) plugin.game().setLives(d, broken, action, value);
        plugin.data().saveAsync();
        msg().send(sender, "modify.lifes", Msg.ph("count", targets.size()), Msg.ph("type", args[2]),
                Msg.ph("action", action.name().toLowerCase(Locale.ROOT)));
    }

    private void modifyHealth(CommandSender sender, String[] args, String usage) {
        if (args.length < 4) {
            usage(sender, usage);
            return;
        }
        List<Player> targets = players(sender, args[2]);
        if (targets == null) {
            msg().send(sender, "modify.player_not_online", Msg.ph("player", args[2]));
            return;
        }
        Action action = Action.parse(args[3]);
        if (action == null) {
            msg().send(sender, "modify.invalid_action");
            return;
        }
        int value = 0;
        if (action != Action.RESET) {
            Integer v = args.length >= 5 ? parseInt(args[4]) : null;
            if (v == null) {
                msg().send(sender, "modify.invalid_number");
                return;
            }
            value = v;
        }
        for (Player p : targets) plugin.game().setHealth(p, action, value);
        plugin.data().saveAsync();
        msg().send(sender, "modify.health", Msg.ph("count", targets.size()),
                Msg.ph("action", action.name().toLowerCase(Locale.ROOT)));
    }

    private void modifyHazard(CommandSender sender, String[] args, String usage) {
        if (args.length < 5) {
            usage(sender, usage);
            return;
        }
        boolean time;
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "level" -> time = false;
            case "time" -> time = true;
            default -> {
                msg().send(sender, "modify.invalid_subtype");
                return;
            }
        }
        List<PlayerData> targets = dataTargets(sender, args[3]);
        if (targets == null) {
            msg().send(sender, "invalid_player", Msg.ph("player", args[3]));
            return;
        }
        Action action = Action.parse(args[4]);
        if (action == null) {
            msg().send(sender, "modify.invalid_action");
            return;
        }
        if (!time) {
            int value = 0;
            if (action != Action.RESET) {
                Integer v = args.length >= 6 ? parseInt(args[5]) : null;
                if (v == null) {
                    msg().send(sender, "modify.invalid_number");
                    return;
                }
                value = v;
            }
            for (PlayerData d : targets) plugin.hazard().setLevel(d, action, value);
        } else {
            long value = 0;
            if (action != Action.RESET) {
                if (args.length < 6) {
                    msg().send(sender, "modify.invalid_time");
                    return;
                }
                try {
                    value = TimeUtil.parse(args[5]);
                } catch (IllegalArgumentException ex) {
                    msg().send(sender, "modify.invalid_time");
                    return;
                }
                if (value < 0 && action != Action.SET) {
                    msg().send(sender, "modify.infinite_delta");
                    return;
                }
            }
            for (PlayerData d : targets) plugin.hazard().setTime(d, action, value);
        }
        plugin.data().saveAsync();
        msg().send(sender, "modify.hazard", Msg.ph("count", targets.size()), Msg.ph("type", args[2]),
                Msg.ph("action", action.name().toLowerCase(Locale.ROOT)));
    }

    // ------------------------------------------------------------------ pvp / announce

    private void pvp(CommandSender sender, String[] args) {
        if (args.length < 2 || args[1].equalsIgnoreCase("status")) {
            msg().send(sender, "pvp.status", Msg.ph("pvp", plugin.game().pvpEnabled() ? "activado" : "desactivado"));
            return;
        }
        boolean on;
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "on" -> on = true;
            case "off" -> on = false;
            default -> {
                usage(sender, "/de pvp <on|off|status>");
                return;
            }
        }
        if (plugin.game().pvpEnabled() == on) {
            msg().send(sender, on ? "pvp.already_on" : "pvp.already_off");
            return;
        }
        plugin.game().setPvp(on);
    }

    private void announce(CommandSender sender, String[] args) {
        String usage = "/de announce <difficulty_change|announcement> <jugador|*> \"<titulo>\" \"<mensaje>\"";
        if (args.length < 4) {
            usage(sender, usage);
            return;
        }
        String type = args[1].toLowerCase(Locale.ROOT);
        if (!type.equals("difficulty_change") && !type.equals("announcement")) {
            usage(sender, usage);
            return;
        }
        List<Player> targets = players(sender, args[2]);
        if (targets == null) {
            msg().send(sender, "invalid_player", Msg.ph("player", args[2]));
            return;
        }
        List<String> text = tokens(args, 3);
        if (text.isEmpty()) {
            usage(sender, usage);
            return;
        }
        String title = text.get(0);
        String message = text.size() >= 2 ? text.get(1) : "";
        plugin.game().announce(type, targets, title, message);
        msg().send(sender, "announce.sent", Msg.ph("count", targets.size()));
    }

    // ------------------------------------------------------------------ tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(PERMISSION)) return List.of();
        List<String> out = new ArrayList<>();
        List<String> names = new ArrayList<>();
        names.add("*");
        for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());

        if (args.length == 1) {
            out.addAll(List.of("help", "reload", "info", "animation", "roulette", "modify", "pvp", "announce"));
        } else {
            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "animation", "animacion" -> {
                    if (args.length == 2) out.addAll(List.of("play", "stop", "list"));
                    else if (args.length == 3 && args[1].equalsIgnoreCase("play")) out.addAll(plugin.animations().keyList());
                    else if (args.length == 3) out.addAll(names);
                    else if (args.length == 4 && args[1].equalsIgnoreCase("play")) out.addAll(names);
                    else if (args.length == 5 && args[1].equalsIgnoreCase("play")) out.add("broadcast");
                }
                case "roulette", "ruleta" -> {
                    if (args.length == 2) {
                        out.addAll(List.of("random", "history"));
                        out.addAll(plugin.animations().keyList());
                    } else if (args.length == 3) out.addAll(names);
                }
                case "modify" -> {
                    if (args.length == 2) out.addAll(List.of("lifes", "health", "hazard"));
                    else {
                        String cat = args[1].toLowerCase(Locale.ROOT);
                        int shift = cat.equals("health") ? 0 : 1;
                        if (args.length == 3 && shift == 1) {
                            out.addAll(cat.equals("hazard") ? List.of("level", "time") : List.of("current", "broken"));
                        } else if (args.length == 3 + shift) out.addAll(names);
                        else if (args.length == 4 + shift) out.addAll(List.of("add", "set", "remove", "reset"));
                    }
                }
                case "pvp" -> {
                    if (args.length == 2) out.addAll(List.of("on", "off", "status"));
                }
                case "announce" -> {
                    if (args.length == 2) out.addAll(List.of("difficulty_change", "announcement"));
                    else if (args.length == 3) out.addAll(names);
                }
                case "info" -> {
                    if (args.length == 2) out.addAll(names);
                }
                default -> { }
            }
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
