package dev.desafioextremo;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Decide el orden de las ruletas/momentos para que queden repartidos.
 *
 * Reglas:
 *  - Se usa una "bolsa": todas las animaciones salen una vez antes de que alguna se repita.
 *  - Una animacion no puede volver a salir dentro de las ultimas {@code pairGap} jugadas.
 *  - Los pares prohibidos (ej. ruleta roja y momento Reviil) nunca quedan a menos de
 *    {@code pairGap} jugadas el uno del otro, en ningun orden.
 *
 * Es logica pura (sin Bukkit) para poder probarla con tests.
 */
public final class RouletteSequencer {

    private static final int HISTORY_CAP = 32;

    private final List<String> pool;
    private final Map<String, Set<String>> incompatible = new HashMap<>();
    private final int pairGap;
    private final Random random;
    private final Deque<String> history = new ArrayDeque<>(); // el primero es el mas reciente
    private final List<String> bag = new ArrayList<>();

    public RouletteSequencer(Collection<String> pool,
                             Collection<? extends List<String>> forbiddenPairs,
                             int pairGap,
                             Random random,
                             Collection<String> previousHistoryNewestFirst) {
        if (pool == null || pool.isEmpty()) {
            throw new IllegalArgumentException("La lista de ruletas no puede estar vacia");
        }
        this.pool = new ArrayList<>(new java.util.LinkedHashSet<>(pool));
        this.pairGap = Math.max(1, pairGap);
        this.random = random;
        if (forbiddenPairs != null) {
            for (List<String> pair : forbiddenPairs) {
                if (pair == null || pair.size() < 2) continue;
                String a = pair.get(0);
                String b = pair.get(1);
                if (!this.pool.contains(a) || !this.pool.contains(b)) continue;
                incompatible.computeIfAbsent(a, k -> new HashSet<>()).add(b);
                incompatible.computeIfAbsent(b, k -> new HashSet<>()).add(a);
            }
        }
        if (previousHistoryNewestFirst != null) {
            for (String key : previousHistoryNewestFirst) {
                if (history.size() >= HISTORY_CAP) break;
                if (this.pool.contains(key)) history.addLast(key);
            }
        }
    }

    /** Devuelve la siguiente animacion y la anota en el historial. */
    public String next() {
        if (bag.isEmpty()) refill();

        String chosen = firstAllowed(bag);
        if (chosen != null) {
            bag.remove(chosen);
        } else {
            // Lo que queda en la bolsa choca con lo ultimo que salio: buscar en todo el pool.
            List<String> all = new ArrayList<>(pool);
            Collections.shuffle(all, random);
            chosen = firstAllowed(all);
            if (chosen != null) {
                bag.remove(chosen);
            } else {
                // Pool demasiado chico para cumplir la regla: al menos evitar repetir la ultima.
                String last = history.peekFirst();
                for (String candidate : all) {
                    if (!candidate.equals(last)) {
                        chosen = candidate;
                        break;
                    }
                }
                if (chosen == null) chosen = all.get(0);
                bag.remove(chosen);
            }
        }

        history.addFirst(chosen);
        while (history.size() > HISTORY_CAP) history.removeLast();
        return chosen;
    }

    /** Historial, de la mas reciente a la mas antigua. */
    public List<String> history() {
        return new ArrayList<>(history);
    }

    private void refill() {
        bag.clear();
        bag.addAll(pool);
        Collections.shuffle(bag, random);
    }

    private String firstAllowed(List<String> candidates) {
        for (String candidate : candidates) {
            if (allowed(candidate)) return candidate;
        }
        return null;
    }

    private boolean allowed(String candidate) {
        Set<String> bad = incompatible.getOrDefault(candidate, Set.of());
        int seen = 0;
        Iterator<String> it = history.iterator();
        while (it.hasNext() && seen < pairGap) {
            String previous = it.next();
            if (previous.equals(candidate)) return false;
            if (bad.contains(previous)) return false;
            seen++;
        }
        return true;
    }
}
