package dev.desafioextremo;

import dev.desafioextremo.DataStore.PlayerData;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

/** Vidas, salud maxima, PvP global y avisos del modo Extremo. */
public final class GameService {

    public enum Action {
        ADD, SET, REMOVE, RESET;

        public static Action parse(String raw) {
            try {
                return valueOf(raw.trim().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    private final DesafioExtremo plugin;
    private final Set<UUID> eliminatedPending = new HashSet<>();
    private final Map<UUID, Location> deathLocations = new HashMap<>();
    private HazardService hazard;

    public GameService(DesafioExtremo plugin) {
        this.plugin = plugin;
    }

    public void setHazard(HazardService hazard) {
        this.hazard = hazard;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private Msg msg() {
        return plugin.msg();
    }

    // ------------------------------------------------------------- datos base

    public int startLives() {
        return Math.max(1, cfg().getInt("settings.start_lives", 3));
    }

    public int baseHealth() {
        return Math.max(2, cfg().getInt("settings.base_health_points", 20));
    }

    public int minHealth() {
        return Math.max(1, cfg().getInt("settings.min_health_points", 2));
    }

    public PlayerData data(Player p) {
        return plugin.data().get(p.getUniqueId(), p.getName(), startLives(), baseHealth());
    }

    public int maxLives(PlayerData d) {
        return Math.max(1, startLives() - d.broken);
    }

    public void clamp(PlayerData d) {
        d.broken = Math.max(0, Math.min(d.broken, startLives() - 1));
        d.lives = Math.max(0, Math.min(d.lives, maxLives(d)));
        d.healthPoints = Math.max(minHealth(), d.healthPoints);
    }

    public void applyHealth(Player p) {
        PlayerData d = data(p);
        clamp(d);
        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr == null) return;
        attr.setBaseValue(d.healthPoints);
        if (p.getHealth() > d.healthPoints) p.setHealth(d.healthPoints);
    }

    public net.kyori.adventure.text.minimessage.tag.resolver.TagResolver[] placeholders(Player p, PlayerData d) {
        return new net.kyori.adventure.text.minimessage.tag.resolver.TagResolver[] {
                Msg.ph("player", p == null ? d.name : p.getName()),
                Msg.ph("lives", d.lives),
                Msg.ph("max_lives", maxLives(d)),
                Msg.ph("broken", d.broken),
                Msg.ph("health", d.healthPoints),
                Msg.ph("hearts", d.healthPoints / 2.0),
                Msg.ph("hazard_level", d.hazardLevel)
        };
    }

    // ------------------------------------------------------------- muerte

    private boolean bypassLifeLoss(Player p) {
        ConfigurationSection b = cfg().getConfigurationSection("gameplay.death.life_loss.bypass");
        if (b == null) return false;
        String perm = b.getString("permission", "");
        if (!perm.isBlank() && p.hasPermission(perm)) return true;
        if (b.getBoolean("operator", false) && p.isOp()) return true;
        if (b.getStringList("gamemodes").stream().anyMatch(g -> g.equalsIgnoreCase(p.getGameMode().name()))) return true;
        if (b.getStringList("worlds").stream().anyMatch(w -> w.equalsIgnoreCase(p.getWorld().getName()))) return true;
        EntityDamageEvent last = p.getLastDamageCause();
        if (last != null) {
            String cause = last.getCause().name();
            if (b.getStringList("causes").stream().anyMatch(c -> c.equalsIgnoreCase(cause))) return true;
            if (last instanceof EntityDamageByEntityEvent byEntity) {
                Entity damager = byEntity.getDamager();
                String type = damager.getType().name();
                if (b.getStringList("entities").stream().anyMatch(t -> t.equalsIgnoreCase(type))) return true;
            }
        }
        return false;
    }

    public void handleDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        FileConfiguration c = cfg();

        // Mensaje vanilla
        Component vanilla = e.deathMessage();
        if (c.getBoolean("gameplay.death.vanilla_message.disable", true)) {
            e.deathMessage(null);
            if (c.getBoolean("gameplay.death.vanilla_message.replace", true) && vanilla != null) {
                Component out = msg().get("death", Msg.phc("death_message", vanilla), Msg.ph("player", p.getName()));
                Bukkit.broadcast(out);
            }
        }

        // Hazard: kill del asesino y penalizaciones de la victima
        if (hazard != null && hazard.enabled()) {
            Player killer = p.getKiller();
            if (killer != null && !killer.getUniqueId().equals(p.getUniqueId())) hazard.onKill(killer);
            hazard.onDeath(p);
        }

        // Vidas
        if (!c.getBoolean("gameplay.death.life_loss.enabled", true)) return;
        if (bypassLifeLoss(p)) return;

        PlayerData d = data(p);
        int amount = Math.max(1, c.getInt("gameplay.death.life_loss.amount", 1));
        d.lives = Math.max(0, d.lives - amount);
        clamp(d);
        boolean eliminated = d.lives <= 0;
        String section = eliminated ? "eliminated" : "lost_life";
        ConfigurationSection s = c.getConfigurationSection("gameplay.death." + section);
        if (s == null) s = c.createSection("gameplay.death." + section);

        if (s.getBoolean("keep_inventory", false)) {
            e.setKeepInventory(true);
            e.getDrops().clear();
            e.setKeepLevel(true);
            e.setDroppedExp(0);
        }
        if (s.getBoolean("immediate_respawn", true)) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline() && p.isDead()) p.spigot().respawn();
            }, 1L);
        }

        var ph = placeholders(p, d);
        if (eliminated) {
            eliminatedPending.add(p.getUniqueId());
            if (s.getBoolean("tp_back_death", false)) deathLocations.put(p.getUniqueId(), p.getLocation().clone());
            ConfigurationSection bc = s.getConfigurationSection("broadcast");
            if (bc != null) {
                if (bc.getBoolean("message", true)) Bukkit.broadcast(msg().get("eliminated.broadcast", ph));
                if (bc.getBoolean("actionbar", false)) {
                    Component bar = msg().get("eliminated.broadcast_actionbar", ph);
                    for (Player online : Bukkit.getOnlinePlayers()) online.sendActionBar(bar);
                }
                if (bc.getBoolean("animation", true)) {
                    plugin.animations().playTo("eliminated", new ArrayList<Player>(Bukkit.getOnlinePlayers()));
                }
            }
            scheduleBan(p, s);
        } else {
            ConfigurationSection pl = s.getConfigurationSection("player");
            ConfigurationSection bc = s.getConfigurationSection("broadcast");
            boolean playerAnim = pl != null && pl.getBoolean("animation", true);
            boolean broadcastAnim = bc != null && bc.getBoolean("animation", true);
            if (pl != null) {
                if (pl.getBoolean("message", true)) p.sendMessage(msg().get("lost_life.player", ph));
                if (pl.getBoolean("actionbar", true)) p.sendActionBar(msg().get("lost_life.player_actionbar", ph));
            }
            if (bc != null) {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (online.getUniqueId().equals(p.getUniqueId())) continue;
                    if (bc.getBoolean("message", true)) online.sendMessage(msg().get("lost_life.broadcast", ph));
                    if (bc.getBoolean("actionbar", false)) online.sendActionBar(msg().get("lost_life.broadcast_actionbar", ph));
                }
            }
            if (playerAnim) {
                plugin.animations().play("lost_life", List.of(p), broadcastAnim);
            } else if (broadcastAnim) {
                List<Player> others = new ArrayList<>(Bukkit.getOnlinePlayers());
                others.removeIf(o -> o.getUniqueId().equals(p.getUniqueId()));
                plugin.animations().playTo("lost_life", others);
            }
        }
        plugin.data().saveAsync();
    }

    private void scheduleBan(Player p, ConfigurationSection eliminatedSection) {
        ConfigurationSection ban = eliminatedSection.getConfigurationSection("ban");
        if (ban == null || !ban.getBoolean("enable", false)) return;
        long delay = Math.max(0, ban.getInt("after_seconds", 14)) * 20L;
        String reason = ban.getString("reason", "Te quedaste sin vidas.");
        String name = p.getName();
        Bukkit.getScheduler().runTaskLater(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " " + reason), delay);
    }

    /** Ajusta el respawn de un jugador eliminado. Devuelve la ubicacion a usar o null. */
    public Location respawnLocationFor(Player p) {
        return deathLocations.remove(p.getUniqueId());
    }

    public void afterRespawn(Player p) {
        applyHealth(p);
        if (eliminatedPending.remove(p.getUniqueId())) {
            if (cfg().getBoolean("gameplay.death.eliminated.spectator_mode", false)) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline()) p.setGameMode(GameMode.SPECTATOR);
                }, 2L);
            }
        }
        if (hazard != null) hazard.applyTag(p);
    }

    // ------------------------------------------------------------- acciones (penalizaciones)

    /** Ejecuta acciones del tipo 'player_health: -2' sobre un jugador. */
    public void runActions(Player p, List<String> actions) {
        PlayerData d = data(p);
        for (String raw : actions) {
            int idx = raw.indexOf(':');
            if (idx < 0) continue;
            String key = raw.substring(0, idx).trim().toLowerCase(Locale.ROOT);
            String value = raw.substring(idx + 1).trim();
            try {
                switch (key) {
                    case "player_lifes" -> d.lives += Integer.parseInt(value);
                    case "player_life_slots" -> d.broken -= Integer.parseInt(value);
                    case "player_health" -> d.healthPoints += Integer.parseInt(value);
                    case "send_player_message" -> p.sendMessage(msg().get(value, placeholders(p, d)));
                    case "send_player_animation" -> plugin.animations().play(value, List.of(p), false);
                    default -> plugin.getLogger().warning("Accion desconocida: " + raw);
                }
            } catch (NumberFormatException ex) {
                plugin.getLogger().warning("Valor invalido en la accion: " + raw);
            }
        }
        clamp(d);
        applyHealth(p);
        plugin.data().saveAsync();
    }

    // ------------------------------------------------------------- /de modify

    public static int apply(int current, Action action, int value, int resetValue) {
        return switch (action) {
            case ADD -> current + value;
            case REMOVE -> current - value;
            case SET -> value;
            case RESET -> resetValue;
        };
    }

    public void setLives(PlayerData d, boolean broken, Action action, int value) {
        if (broken) d.broken = apply(d.broken, action, value, 0);
        else d.lives = apply(d.lives, action, value, maxLives(d));
        clamp(d);
        Player online = Bukkit.getPlayer(d.id);
        if (online != null && d.lives > 0 && online.getGameMode() == GameMode.SPECTATOR
                && cfg().getBoolean("gameplay.death.eliminated.spectator_mode", false)) {
            online.setGameMode(Bukkit.getDefaultGameMode());
        }
    }

    public void setHealth(Player p, Action action, int value) {
        PlayerData d = data(p);
        d.healthPoints = apply(d.healthPoints, action, value, baseHealth());
        clamp(d);
        applyHealth(p);
    }

    // ------------------------------------------------------------- PvP

    public boolean pvpEnabled() {
        return plugin.data().pvp();
    }

    public void setPvp(boolean on) {
        plugin.data().setPvp(on);
        plugin.data().saveAsync();
        String key = on ? "pvp_on" : "pvp_off";
        Collection<? extends Player> all = Bukkit.getOnlinePlayers();
        plugin.animations().playTo(key, new ArrayList<Player>(all));
        plugin.animations().playChatSoundTo(key, new ArrayList<Player>(all));
        Bukkit.broadcast(msg().get(key));
    }

    // ------------------------------------------------------------- anuncios

    public void announce(String type, Collection<? extends Player> targets, String title, String message) {
        var title_ph = net.kyori.adventure.text.minimessage.tag.resolver.Placeholder.parsed("title", title);
        var message_ph = net.kyori.adventure.text.minimessage.tag.resolver.Placeholder.parsed("message", message);
        List<Player> list = new ArrayList<>(targets);
        if (type.equals("difficulty_change")) {
            plugin.animations().playTo("difficulty_change", list);
            plugin.animations().playChatSoundTo("difficulty_change", list);
            Component text = msg().get("announce.difficulty_change", title_ph, message_ph);
            for (Player p : list) p.sendMessage(text);
        } else {
            plugin.animations().playTo("announcement", list);
            plugin.animations().playChatSoundTo("announcement", list);
            Component text = msg().get("announce.announcement", title_ph, message_ph);
            Component bar = msg().get("announce.announcement_actionbar", title_ph, message_ph);
            for (Player p : list) {
                p.sendMessage(text);
                p.sendActionBar(bar);
            }
        }
    }
}
