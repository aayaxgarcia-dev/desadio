package dev.desafioextremo;

import java.io.File;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class DesafioExtremo extends JavaPlugin {

    private Msg msg;
    private DataStore data;
    private AnimationManager animations;
    private GameService game;
    private HazardService hazard;
    private RouletteService roulette;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "animations.yml").exists()) saveResource("animations.yml", false);

        msg = new Msg(getConfig());
        data = new DataStore(this);
        data.load();
        if (!data.pvpLoaded()) data.setPvp(getConfig().getBoolean("gameplay.pvp.default", true));
        animations = new AnimationManager(this);
        game = new GameService(this);
        hazard = new HazardService(this, game);
        game.setHazard(hazard);
        roulette = new RouletteService(this);
        loadAnimationsFile();
        roulette.reload();

        getServer().getPluginManager().registerEvents(new GameListener(this, game), this);

        DeCommand command = new DeCommand(this);
        PluginCommand pc = getCommand("de");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }

        getServer().getScheduler().runTaskTimer(this, () -> hazard.tick(), 200L, 200L);
        getServer().getScheduler().runTaskTimer(this, () -> data.saveAsync(), 6000L, 6000L);

        for (Player p : getServer().getOnlinePlayers()) {
            game.applyHealth(p);
            hazard.applyTag(p);
        }
        getLogger().info("DesafioExtremo " + getPluginMeta().getVersion() + " activo.");
    }

    @Override
    public void onDisable() {
        if (animations != null) animations.stopAll();
        if (hazard != null) hazard.clearTags();
        if (data != null) data.saveNow();
    }

    private void loadAnimationsFile() {
        File file = new File(getDataFolder(), "animations.yml");
        animations.load(YamlConfiguration.loadConfiguration(file));
    }

    /** Recarga config.yml y animations.yml. Devuelve false si algo fallo. */
    public boolean reloadAll() {
        try {
            reloadConfig();
            msg.reload(getConfig());
            loadAnimationsFile();
            roulette.reload();
            for (Player p : getServer().getOnlinePlayers()) {
                game.applyHealth(p);
                hazard.applyTag(p);
            }
            return true;
        } catch (RuntimeException ex) {
            getLogger().severe("Error al recargar: " + ex);
            return false;
        }
    }

    public Msg msg() {
        return msg;
    }

    public DataStore data() {
        return data;
    }

    public AnimationManager animations() {
        return animations;
    }

    public GameService game() {
        return game;
    }

    public HazardService hazard() {
        return hazard;
    }

    public RouletteService roulette() {
        return roulette;
    }
}
