package dev.desafioextremo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

/** Lanza ruletas (animacion + mensaje de chat) y reparte el orden de las aleatorias. */
public final class RouletteService {

    private final DesafioExtremo plugin;
    private RouletteSequencer sequencer;

    public RouletteService(DesafioExtremo plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        FileConfiguration cfg = plugin.getConfig();
        List<String> pool = new ArrayList<>();
        for (String key : cfg.getStringList("roulette.pool")) {
            if (plugin.animations().has(key)) pool.add(key);
            else plugin.getLogger().warning("roulette.pool: la animacion '" + key + "' no existe en animations.yml");
        }
        List<List<String>> pairs = new ArrayList<>();
        for (List<?> raw : cfg.getList("roulette.forbidden_pairs", List.of()).stream()
                .filter(o -> o instanceof List).map(o -> (List<?>) o).toList()) {
            List<String> pair = new ArrayList<>();
            for (Object o : raw) pair.add(String.valueOf(o));
            pairs.add(pair);
        }
        int gap = cfg.getInt("roulette.pair_gap", 2);
        if (pool.isEmpty()) {
            sequencer = null;
            plugin.getLogger().warning("roulette.pool esta vacio: /de roulette random no funcionara.");
            return;
        }
        sequencer = new RouletteSequencer(pool, pairs, gap, new Random(), plugin.data().rouletteHistory());
    }

    public boolean hasPool() {
        return sequencer != null;
    }

    /** Siguiente ruleta segun las reglas de separacion; guarda el historial. */
    public String nextRandom() {
        String key = sequencer.next();
        plugin.data().setRouletteHistory(sequencer.history());
        plugin.data().saveAsync();
        return key;
    }

    public List<String> history() {
        return sequencer == null ? List.of() : sequencer.history();
    }

    /** "red" -> "red_roulette"; si ya es una clave de animacion se usa tal cual. Devuelve null si no existe. */
    public String resolveKey(String token) {
        String t = token.toLowerCase();
        if (plugin.animations().has(t)) return t;
        if (plugin.animations().has(t + "_roulette")) return t + "_roulette";
        return null;
    }

    private static String colorOf(String key) {
        return key.endsWith("_roulette") ? key.substring(0, key.length() - "_roulette".length()) : "default";
    }

    public void play(String key, Collection<? extends Player> targets, String title, String message) {
        List<Player> list = new ArrayList<>(targets);
        plugin.animations().play(key, list, false);

        String color = colorOf(key);
        FileConfiguration cfg = plugin.getConfig();
        ConfigurationSection templates = cfg.getConfigurationSection("roulettes");
        String path = templates != null && templates.isList(color) ? "roulettes." + color : "roulettes.default";

        List<Component> lines = plugin.msg().list(path,
                Placeholder.parsed("title", title), Placeholder.parsed("message", message));

        // El mensaje de chat llega cuando termina la animacion.
        long delay = plugin.animations().durationTicks(key);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            List<Player> still = new ArrayList<>();
            for (Player p : list) if (p.isOnline()) still.add(p);
            for (Player p : still) for (Component line : lines) p.sendMessage(line);
            plugin.animations().playChatSound(key, still, false);
        }, delay);
    }
}
