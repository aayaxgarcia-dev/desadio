package dev.desafioextremo;

import dev.desafioextremo.DataStore.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public final class GameListener implements Listener {

    private final DesafioExtremo plugin;
    private final GameService game;

    public GameListener(DesafioExtremo plugin, GameService game) {
        this.plugin = plugin;
        this.game = game;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        game.handleDeath(e);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Location back = game.respawnLocationFor(p);
        if (back != null) e.setRespawnLocation(back);
        // Esperar un tick: el atributo de vida maxima se aplica con el jugador ya vivo.
        Bukkit.getScheduler().runTask(plugin, () -> game.afterRespawn(p));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        PlayerData d = game.data(p);
        game.clamp(d);
        game.applyHealth(p);
        if (plugin.hazard() != null) plugin.hazard().applyTag(p);
        if (d.lives <= 0 && plugin.getConfig().getBoolean("gameplay.death.eliminated.spectator_mode", false)) {
            p.setGameMode(GameMode.SPECTATOR);
        }
        if (plugin.getConfig().getBoolean("gameplay.miscellaneous.messages.join", true)) {
            e.joinMessage(plugin.msg().get("join", Msg.ph("player", p.getName())));
        }
        plugin.data().saveAsync();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.animations().stopFor(e.getPlayer());
        if (plugin.getConfig().getBoolean("gameplay.miscellaneous.messages.leave", true)) {
            e.quitMessage(plugin.msg().get("leave", Msg.ph("player", e.getPlayer().getName())));
        }
    }

    /** PvP global: cuando esta apagado se cancela el dano jugador contra jugador (incluye proyectiles). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (game.pvpEnabled()) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        Entity damager = e.getDamager();
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Entity shooter) damager = shooter;
        if (damager instanceof Player attacker && !attacker.getUniqueId().equals(victim.getUniqueId())) {
            e.setCancelled(true);
        }
    }
}
