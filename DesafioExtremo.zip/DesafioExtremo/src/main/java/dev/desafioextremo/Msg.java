package dev.desafioextremo;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

/** Mensajes en MiniMessage leidos de config.yml (seccion "messages"). */
public final class Msg {

    private final MiniMessage mm = MiniMessage.miniMessage();
    private FileConfiguration cfg;

    public Msg(FileConfiguration cfg) {
        this.cfg = cfg;
    }

    public void reload(FileConfiguration cfg) {
        this.cfg = cfg;
    }

    public static TagResolver ph(String key, Object value) {
        return Placeholder.unparsed(key, String.valueOf(value));
    }

    public static TagResolver phc(String key, Component value) {
        return Placeholder.component(key, value);
    }

    private TagResolver[] withPrefix(TagResolver[] extra) {
        TagResolver[] all = new TagResolver[extra.length + 1];
        all[0] = Placeholder.parsed("prefix", cfg.getString("messages.prefix", ""));
        System.arraycopy(extra, 0, all, 1, extra.length);
        return all;
    }

    /** Parsea un texto cualquiera (no una ruta) con los placeholders. */
    public Component parse(String template, TagResolver... resolvers) {
        return mm.deserialize(template == null ? "" : template, withPrefix(resolvers));
    }

    public boolean has(String path) {
        return cfg.isString("messages." + path) || cfg.isList("messages." + path);
    }

    public Component get(String path, TagResolver... resolvers) {
        String raw = cfg.getString("messages." + path);
        if (raw == null) return Component.text("[mensaje faltante: " + path + "]");
        return parse(raw, resolvers);
    }

    public List<Component> list(String path, TagResolver... resolvers) {
        List<Component> out = new ArrayList<>();
        for (String line : cfg.getStringList(path)) out.add(parse(line, resolvers));
        return out;
    }

    public void send(CommandSender to, String path, TagResolver... resolvers) {
        if (!has(path)) return;
        to.sendMessage(get(path, resolvers));
    }
}
