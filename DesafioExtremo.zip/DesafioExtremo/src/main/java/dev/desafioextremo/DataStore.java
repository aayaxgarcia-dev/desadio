package dev.desafioextremo;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/** Guarda en data.yml los jugadores, el estado del PvP y el historial de ruletas. */
public final class DataStore {

    public static final class PlayerData {
        public final UUID id;
        public String name;
        public int lives;
        public int broken;
        public int healthPoints;
        public int hazardLevel = 1;
        public int hazardKills = 0;
        public long hazardExpires = TimeUtil.INFINITE;

        PlayerData(UUID id, String name, int lives, int healthPoints) {
            this.id = id;
            this.name = name;
            this.lives = lives;
            this.healthPoints = healthPoints;
        }
    }

    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerData> players = new LinkedHashMap<>();
    private boolean pvp = true;
    private List<String> rouletteHistory = new ArrayList<>();
    private boolean pvpLoaded = false;

    public DataStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        players.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (yml.contains("pvp")) {
            pvp = yml.getBoolean("pvp", true);
            pvpLoaded = true;
        }
        rouletteHistory = new ArrayList<>(yml.getStringList("roulette_history"));
        ConfigurationSection sec = yml.getConfigurationSection("players");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection p = sec.getConfigurationSection(key);
            if (p == null) continue;
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            PlayerData d = new PlayerData(id, p.getString("name", key), p.getInt("lives", 3), p.getInt("health", 20));
            d.broken = p.getInt("broken", 0);
            d.hazardLevel = p.getInt("hazard_level", 1);
            d.hazardKills = p.getInt("hazard_kills", 0);
            d.hazardExpires = p.getLong("hazard_expires", TimeUtil.INFINITE);
            players.put(id, d);
        }
    }

    private String serialize() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("pvp", pvp);
        yml.set("roulette_history", rouletteHistory);
        for (PlayerData d : players.values()) {
            String base = "players." + d.id;
            yml.set(base + ".name", d.name);
            yml.set(base + ".lives", d.lives);
            yml.set(base + ".broken", d.broken);
            yml.set(base + ".health", d.healthPoints);
            yml.set(base + ".hazard_level", d.hazardLevel);
            yml.set(base + ".hazard_kills", d.hazardKills);
            yml.set(base + ".hazard_expires", d.hazardExpires);
        }
        return yml.saveToString();
    }

    /** Serializa en el hilo principal y escribe el archivo en otro hilo. */
    public void saveAsync() {
        final String text = serialize();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> write(text));
    }

    /** Para onDisable: escribe en el momento. */
    public void saveNow() {
        write(serialize());
    }

    private synchronized void write(String text) {
        try {
            plugin.getDataFolder().mkdirs();
            Files.writeString(file.toPath(), text, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            plugin.getLogger().severe("No se pudo guardar data.yml: " + ex.getMessage());
        }
    }

    public PlayerData get(UUID id, String name, int defaultLives, int defaultHealth) {
        PlayerData d = players.get(id);
        if (d == null) {
            d = new PlayerData(id, name, defaultLives, defaultHealth);
            players.put(id, d);
        } else if (name != null && !name.equals(d.name)) {
            d.name = name;
        }
        return d;
    }

    public PlayerData find(UUID id) {
        return players.get(id);
    }

    public PlayerData findByName(String name) {
        for (PlayerData d : players.values()) {
            if (d.name != null && d.name.equalsIgnoreCase(name)) return d;
        }
        return null;
    }

    public Collection<PlayerData> all() {
        return players.values();
    }

    public boolean pvp() {
        return pvp;
    }

    public boolean pvpLoaded() {
        return pvpLoaded;
    }

    public void setPvp(boolean value) {
        this.pvp = value;
        this.pvpLoaded = true;
    }

    public List<String> rouletteHistory() {
        return rouletteHistory;
    }

    public void setRouletteHistory(List<String> history) {
        this.rouletteHistory = new ArrayList<>(history);
    }
}
