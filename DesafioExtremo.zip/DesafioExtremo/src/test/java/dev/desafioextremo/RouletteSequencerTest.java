package dev.desafioextremo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.junit.jupiter.api.Test;

class RouletteSequencerTest {

    private static final List<String> POOL = List.of(
            "aqua_roulette", "blue_roulette", "purple_roulette", "pink_roulette", "red_roulette",
            "orange_roulette", "yellow_roulette", "green_roulette", "otter_moment", "reviil_moment");
    private static final List<List<String>> PAIRS = List.of(
            List.of("red_roulette", "reviil_moment"), List.of("pink_roulette", "otter_moment"));

    @Test
    void reviilNeverFollowsRedAndNothingRepeatsInARow() {
        for (long seed = 0; seed < 50; seed++) {
            RouletteSequencer seq = new RouletteSequencer(POOL, PAIRS, 2, new Random(seed), List.of());
            List<String> out = new ArrayList<>();
            for (int i = 0; i < 2000; i++) out.add(seq.next());
            for (int i = 1; i < out.size(); i++) {
                assertFalse(out.get(i).equals(out.get(i - 1)), "repetida seguida en " + i);
                for (int back = 1; back <= 2 && i - back >= 0; back++) {
                    String a = out.get(i);
                    String b = out.get(i - back);
                    boolean redPair = (a.equals("red_roulette") && b.equals("reviil_moment"))
                            || (a.equals("reviil_moment") && b.equals("red_roulette"));
                    assertFalse(redPair, "roja y Reviil muy juntas en " + i + " (seed " + seed + ")");
                }
            }
        }
    }

    @Test
    void everyAnimationAppearsBeforeAnyRepeatsInTheFirstRound() {
        RouletteSequencer seq = new RouletteSequencer(POOL, PAIRS, 2, new Random(7), List.of());
        Set<String> first = new HashSet<>();
        for (int i = 0; i < POOL.size(); i++) first.add(seq.next());
        assertEquals(POOL.size(), first.size());
    }

    @Test
    void respectsHistoryFromPreviousRun() {
        RouletteSequencer seq = new RouletteSequencer(POOL, PAIRS, 2, new Random(3), List.of("red_roulette"));
        for (int i = 0; i < 200; i++) {
            RouletteSequencer fresh = new RouletteSequencer(POOL, PAIRS, 2, new Random(i), List.of("red_roulette"));
            assertFalse(fresh.next().equals("reviil_moment"));
        }
        assertTrue(seq.history().contains("red_roulette"));
    }

    @Test
    void tinyPoolDoesNotCrash() {
        RouletteSequencer seq = new RouletteSequencer(List.of("a"), List.of(), 2, new Random(1), List.of());
        assertEquals("a", seq.next());
        assertEquals("a", seq.next());
    }
}
